const express = require("express");
const fs = require("fs");
const path = require("path");

const router = express.Router();
const DB_PATH = path.join(__dirname, "../DATABASE/database.json");

function ensureDB() {
  const dbDir = path.dirname(DB_PATH);

  if (!fs.existsSync(dbDir)) {
    fs.mkdirSync(dbDir, { recursive: true });
  }

  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(
      DB_PATH,
      JSON.stringify({ offers: [] }, null, 2)
    );
  }
}

function readDB() {
  ensureDB();

  try {
    const raw = fs.readFileSync(DB_PATH, "utf8").trim();
    if (!raw) return { offers: [] };

    const db = JSON.parse(raw);
    if (!Array.isArray(db.offers)) db.offers = [];
    return db;
  } catch (error) {
    return { offers: [] };
  }
}

function writeDB(db) {
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}

function generateId() {
  return "OFF-" + Date.now() + "-" + Math.random().toString(36).slice(2, 7);
}

function toNumber(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function normalizeStatus(status) {
  const allowed = ["draft", "sent", "viewed", "booked", "cancelled", "lost", "expired"];
  return allowed.includes(status) ? status : "draft";
}

function getEffectiveStatus(offer) {
  if (!offer.validUntil) return normalizeStatus(offer.status);

  const now = Date.now();
  const validUntil = new Date(offer.validUntil).getTime();

  if (
    Number.isFinite(validUntil) &&
    validUntil < now &&
    !["booked", "cancelled", "lost"].includes(offer.status)
  ) {
    return "expired";
  }

  return normalizeStatus(offer.status);
}

function normalizeOffer(raw) {
  const basePrice = toNumber(raw.basePrice);
  const markupPercent =
    raw.markupPercent != null ? toNumber(raw.markupPercent) : toNumber(raw.markupPct);

  let finalPrice;

  if (raw.price != null && raw.price !== "") {
    finalPrice = toNumber(raw.price);
  } else if (raw.finalPrice != null && raw.finalPrice !== "") {
    finalPrice = toNumber(raw.finalPrice);
  } else {
    finalPrice = +(basePrice * (1 + markupPercent / 100)).toFixed(2);
  }

  const marginAmount =
    raw.marginAmount != null
      ? toNumber(raw.marginAmount)
      : +(finalPrice - basePrice).toFixed(2);

  return {
    id: raw.id || generateId(),
    clientName: raw.clientName || "",
    clientPhone: raw.clientPhone || "",
    destination: raw.destination || "",
    flightRoute: raw.flightRoute || "",
    hotel: raw.hotel || "",
    travelDates: raw.travelDates || "",
    guests: raw.guests || "",
    basePrice,
    markupPercent,
    markupPct: markupPercent,
    price: +finalPrice.toFixed(2),
    finalPrice: +finalPrice.toFixed(2),
    marginAmount: +marginAmount.toFixed(2),
    margin: +marginAmount.toFixed(2),
    currency: raw.currency || "EUR",
    status: normalizeStatus(raw.status || "draft"),
    createdAt: raw.createdAt || new Date().toISOString(),
    updatedAt: raw.updatedAt || raw.createdAt || new Date().toISOString(),
    validUntil: raw.validUntil || null,
    notes: raw.notes || "",
    followUpDate: raw.followUpDate || null,
    bookedAt: raw.bookedAt || null,
    lostAt: raw.lostAt || null,
    cancelledAt: raw.cancelledAt || null,
    clientViewed: Boolean(raw.clientViewed),
    viewedAt: raw.viewedAt || null,
    clicks: toNumber(raw.clicks, 0)
  };
}

function loadDB() {
  const db = readDB();
  db.offers = (db.offers || []).map(normalizeOffer);
  return db;
}

function scoreOffer(offer) {
  const now = Date.now();
  const validUntilTs = offer.validUntil ? new Date(offer.validUntil).getTime() : null;
  const hoursLeft =
    Number.isFinite(validUntilTs) ? (validUntilTs - now) / (1000 * 60 * 60) : null;

  let dealScore = 0;
  let urgencyScore = 0;
  let profitScore = 0;

  const price = toNumber(offer.price);
  const basePrice = toNumber(offer.basePrice);
  const margin = price - basePrice;

  if (offer.clientViewed) dealScore += 30;
  if (offer.status === "viewed") dealScore += 20;
  if (offer.status === "sent") dealScore += 10;
  if (offer.status === "draft") dealScore += 5;

  if (margin >= 500) profitScore += 95;
  else if (margin >= 200) profitScore += 75;
  else if (margin >= 100) profitScore += 55;
  else if (margin >= 30) profitScore += 35;
  else profitScore += 15;

  if (price >= 5000) dealScore += 20;
  else if (price >= 1500) dealScore += 10;

  if (hoursLeft !== null) {
    if (hoursLeft <= 6) urgencyScore += 95;
    else if (hoursLeft <= 24) urgencyScore += 80;
    else if (hoursLeft <= 48) urgencyScore += 60;
    else if (hoursLeft <= 96) urgencyScore += 35;
    else urgencyScore += 10;
  }

  if (offer.followUpDate) {
    const followUpTs = new Date(offer.followUpDate).getTime();
    if (Number.isFinite(followUpTs) && followUpTs <= now) urgencyScore += 25;
  }

  if (["booked", "cancelled", "lost"].includes(offer.status)) {
    dealScore = 0;
    urgencyScore = 0;
  }

  dealScore = Math.min(100, dealScore);
  urgencyScore = Math.min(100, urgencyScore);
  profitScore = Math.min(100, profitScore);

  let clientTemperature = "cold";
  if (dealScore >= 70) clientTemperature = "hot";
  else if (dealScore >= 40) clientTemperature = "warm";

  let nextAction = "Monitor";
  if (offer.status === "draft") nextAction = "Send offer";
  if (offer.status === "sent") nextAction = "Follow up";
  if (offer.status === "viewed") nextAction = "Call client";
  if (urgencyScore >= 80) nextAction = "Urgent follow-up";
  if (offer.followUpDate && new Date(offer.followUpDate).getTime() <= now) {
    nextAction = "Follow-up due now";
  }

  return {
    dealScore,
    urgencyScore,
    profitScore,
    clientTemperature,
    nextAction
  };
}

function enrichOffers(offers) {
  return offers.map((offer) => ({
    ...offer,
    effectiveStatus: getEffectiveStatus(offer),
    ...scoreOffer(offer)
  }));
}

function getStats(offers) {
  const stats = {
    totalOffers: offers.length,
    activeOffers: 0,
    bookedOffers: 0,
    cancelledOffers: 0,
    lostOffers: 0,
    viewedOffers: 0,
    sentOffers: 0,
    totalRevenue: 0,
    totalMargin: 0,
    totalRevenuePotential: 0,
    totalMarginPotential: 0,
    bookedRevenue: 0,
    lostRevenue: 0
  };

  for (const offer of offers) {
    const effectiveStatus = offer.effectiveStatus || getEffectiveStatus(offer);
    const price = toNumber(offer.price);
    const margin = toNumber(offer.marginAmount);

    if (!["booked", "cancelled", "lost", "expired"].includes(effectiveStatus)) {
      stats.activeOffers += 1;
      stats.totalRevenuePotential += price;
      stats.totalMarginPotential += margin;
    }

    if (effectiveStatus === "booked") {
      stats.bookedOffers += 1;
      stats.totalRevenue += price;
      stats.totalMargin += margin;
      stats.bookedRevenue += price;
    }

    if (effectiveStatus === "cancelled") stats.cancelledOffers += 1;
    if (effectiveStatus === "lost") {
      stats.lostOffers += 1;
      stats.lostRevenue += price;
    }
    if (effectiveStatus === "viewed") stats.viewedOffers += 1;
    if (effectiveStatus === "sent") stats.sentOffers += 1;
  }

  for (const key of [
    "totalRevenue",
    "totalMargin",
    "totalRevenuePotential",
    "totalMarginPotential",
    "bookedRevenue",
    "lostRevenue"
  ]) {
    stats[key] = +stats[key].toFixed(2);
  }

  return stats;
}

// ALL OFFERS
router.get("/", (req, res) => {
  const db = loadDB();
  const offers = enrichOffers(db.offers).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  res.json({
    success: true,
    offers,
    stats: getStats(offers)
  });
});

// OLD + NEW STATS COMPAT
router.get("/stats", (req, res) => {
  const db = loadDB();
  const offers = enrichOffers(db.offers);
  res.json(getStats(offers));
});

router.get("/stats/summary", (req, res) => {
  const db = loadDB();
  const offers = enrichOffers(db.offers);
  res.json({
    success: true,
    stats: getStats(offers)
  });
});

// HOT DEALS
router.get("/hot-deals", (req, res) => {
  const db = loadDB();

  const enriched = enrichOffers(db.offers)
    .filter((offer) => !["booked", "cancelled", "lost"].includes(offer.status));

  const hotDeals = [...enriched]
    .sort((a, b) => (b.dealScore + b.urgencyScore + b.profitScore) - (a.dealScore + a.urgencyScore + a.profitScore))
    .slice(0, 5);

  const expiringSoon = [...enriched]
    .filter((o) => o.validUntil)
    .sort((a, b) => new Date(a.validUntil) - new Date(b.validUntil))
    .slice(0, 5);

  const highMargin = [...enriched]
    .sort((a, b) => (toNumber(b.price) - toNumber(b.basePrice)) - (toNumber(a.price) - toNumber(a.basePrice)))
    .slice(0, 5);

  const followUpRequired = [...enriched]
    .filter((o) => o.followUpDate || o.status === "viewed" || o.status === "sent")
    .sort((a, b) => b.urgencyScore - a.urgencyScore)
    .slice(0, 5);

  res.json({
    success: true,
    hotDeals,
    expiringSoon,
    highMargin,
    followUpRequired
  });
});

// SALES BOARD
router.get("/sales-board", (req, res) => {
  const db = loadDB();
  const enriched = enrichOffers(db.offers)
    .filter((o) => !["booked", "cancelled", "lost", "expired"].includes(o.effectiveStatus));

  const hotClients = [...enriched]
    .filter((o) => o.clientTemperature === "hot")
    .sort((a, b) => b.dealScore - a.dealScore)
    .slice(0, 5);

  const callToday = [...enriched]
    .filter((o) => o.nextAction === "Call client" || o.nextAction === "Urgent follow-up" || o.nextAction === "Follow-up due now")
    .sort((a, b) => b.urgencyScore - a.urgencyScore)
    .slice(0, 5);

  const closeDeals = [...enriched]
    .filter((o) => o.dealScore >= 40 || o.urgencyScore >= 60)
    .sort((a, b) => (b.dealScore + b.urgencyScore + b.profitScore) - (a.dealScore + a.urgencyScore + a.profitScore))
    .slice(0, 5);

  const coldLeads = [...enriched]
    .filter((o) => o.clientTemperature === "cold")
    .sort((a, b) => a.dealScore - b.dealScore)
    .slice(0, 5);

  res.json({
    success: true,
    hotClients,
    callToday,
    closeDeals,
    coldLeads
  });
});

// PDF HTML VIEW
router.get("/:id/pdf", (req, res) => {
  const db = loadDB();
  const offer = db.offers.find((o) => o.id === req.params.id);

  if (!offer) return res.status(404).send("Offer not found");

  res.setHeader("Content-Type", "text/html; charset=utf-8");
  res.send(`
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8" />
      <title>${offer.id}</title>
      <style>
        body { font-family: Arial, sans-serif; padding: 40px; color: #111; }
        h1 { margin-bottom: 24px; }
        .price { font-size: 28px; font-weight: bold; margin: 20px 0; }
        .row { margin: 8px 0; }
      </style>
    </head>
    <body>
      <h1>2L1P Neural Travel</h1>
      <div class="row"><b>Client:</b> ${offer.clientName || "TBA"}</div>
      <div class="row"><b>Destination:</b> ${offer.destination || "TBA"}</div>
      <div class="row"><b>Flights:</b> ${offer.flightRoute || "TBA"}</div>
      <div class="row"><b>Hotel:</b> ${offer.hotel || "TBA"}</div>
      <div class="row"><b>Guests:</b> ${offer.guests || "TBA"}</div>
      <div class="row"><b>Dates:</b> ${offer.travelDates || "TBA"}</div>
      <div class="price">${toNumber(offer.price).toFixed(2)} ${offer.currency || "EUR"}</div>
      <div class="row"><b>Status:</b> ${getEffectiveStatus(offer)}</div>
      <div class="row"><b>Valid until:</b> ${offer.validUntil || "-"}</div>
      <div class="row"><b>Offer ID:</b> ${offer.id}</div>
      <div class="row"><b>Notes:</b> ${offer.notes || "-"}</div>
      <div class="row"><b>Follow-up:</b> ${offer.followUpDate || "-"}</div>
    </body>
    </html>
  `);
});

// SINGLE OFFER
router.get("/:id", (req, res) => {
  const db = loadDB();
  const offer = db.offers.find((o) => o.id === req.params.id);

  if (!offer) {
    return res.status(404).json({ success: false, error: "Offer not found" });
  }

  if (!offer.clientViewed) {
    offer.clientViewed = true;
    offer.viewedAt = offer.viewedAt || new Date().toISOString();

    if (!["booked", "cancelled", "lost"].includes(offer.status)) {
      offer.status = "viewed";
    }

    offer.updatedAt = new Date().toISOString();
    writeDB(db);
  }

  res.json({
    success: true,
    offer: {
      ...offer,
      effectiveStatus: getEffectiveStatus(offer),
      ...scoreOffer(offer)
    }
  });
});

// CREATE OFFER
router.post("/", (req, res) => {
  const db = loadDB();
  const body = req.body || {};

  if (!body.destination || String(body.destination).trim() === "") {
    return res.status(400).json({
      success: false,
      message: "Destination is required"
    });
  }

  const basePrice = toNumber(body.basePrice);
  const markupPercent =
    body.markupPercent != null ? toNumber(body.markupPercent) : toNumber(body.markupPct);

  const customFinalPrice =
    body.price !== "" && body.price != null
      ? toNumber(body.price)
      : body.finalPrice !== "" && body.finalPrice != null
        ? toNumber(body.finalPrice)
        : null;

  const finalPrice =
    customFinalPrice !== null
      ? customFinalPrice
      : +(basePrice * (1 + markupPercent / 100)).toFixed(2);

  const marginAmount = +(finalPrice - basePrice).toFixed(2);

  const now = new Date();
  let validUntil;

  if (body.customValidUntil && String(body.customValidUntil).trim() !== "") {
    validUntil = new Date(body.customValidUntil).toISOString();
  } else {
    const validForDays = Math.max(1, parseInt(body.validForDays || body.validDays || "1", 10));
    validUntil = new Date(now.getTime() + validForDays * 24 * 60 * 60 * 1000).toISOString();
  }

  const offer = normalizeOffer({
    id: generateId(),
    clientName: body.clientName || "",
    clientPhone: body.clientPhone || "",
    destination: body.destination || "",
    flightRoute: body.flightRoute || "",
    hotel: body.hotel || "",
    travelDates: body.travelDates || "",
    guests: body.guests || "",
    basePrice,
    markupPercent,
    markupPct: markupPercent,
    price: finalPrice,
    finalPrice,
    marginAmount,
    margin: marginAmount,
    currency: body.currency || "EUR",
    status: body.status || "draft",
    createdAt: now.toISOString(),
    updatedAt: now.toISOString(),
    validUntil,
    notes: body.notes || "",
    followUpDate: body.followUpDate || null,
    bookedAt: null,
    lostAt: null,
    cancelledAt: null,
    clientViewed: false,
    viewedAt: null,
    clicks: 0
  });

  db.offers.unshift(offer);
  writeDB(db);

  res.status(201).json({
    success: true,
    offer
  });
});

// STATUS UPDATE
router.patch("/:id/status", (req, res) => {
  const db = loadDB();
  const offer = db.offers.find((o) => o.id === req.params.id);

  if (!offer) {
    return res.status(404).json({
      success: false,
      message: "Offer not found"
    });
  }

  const nextStatus = normalizeStatus(req.body.status || offer.status);
  offer.status = nextStatus;
  offer.updatedAt = new Date().toISOString();

  if (nextStatus === "booked" && !offer.bookedAt) offer.bookedAt = new Date().toISOString();
  if (nextStatus === "lost" && !offer.lostAt) offer.lostAt = new Date().toISOString();
  if (nextStatus === "cancelled" && !offer.cancelledAt) offer.cancelledAt = new Date().toISOString();
  if (nextStatus === "viewed" && !offer.viewedAt) {
    offer.viewedAt = new Date().toISOString();
    offer.clientViewed = true;
  }

  writeDB(db);

  res.json({
    success: true,
    offer
  });
});

// BOOK OFFER
router.post("/:id/book", (req, res) => {
  const db = loadDB();
  const offer = db.offers.find((o) => o.id === req.params.id);

  if (!offer) {
    return res.status(404).json({
      success: false,
      message: "Offer not found"
    });
  }

  offer.status = "booked";
  offer.bookedAt = offer.bookedAt || new Date().toISOString();
  offer.updatedAt = new Date().toISOString();

  writeDB(db);

  res.json({
    success: true,
    message: "Offer booked successfully",
    offer
  });
});

// CLICK TRACKING
router.post("/:id/click", (req, res) => {
  const db = loadDB();
  const offer = db.offers.find((o) => o.id === req.params.id);

  if (!offer) {
    return res.status(404).json({
      success: false,
      message: "Offer not found"
    });
  }

  offer.clicks = toNumber(offer.clicks, 0) + 1;
  offer.updatedAt = new Date().toISOString();

  writeDB(db);

  res.json({
    success: true,
    clicks: offer.clicks
  });
});

// DELETE OFFER
router.delete("/:id", (req, res) => {
  const db = loadDB();
  const index = db.offers.findIndex((o) => o.id === req.params.id);

  if (index === -1) {
    return res.status(404).json({
      success: false,
      message: "Offer not found"
    });
  }

  const deleted = db.offers.splice(index, 1)[0];
  writeDB(db);

  res.json({
    success: true,
    offer: deleted
  });
});

module.exports = router;