﻿const adminOffers = document.getElementById("adminOffers");
const adminStats = document.getElementById("adminStats");
const hotDealWidgets = document.getElementById("hotDealWidgets");
const salesBoardWidgets = document.getElementById("salesBoardWidgets");
const filterIds = ["q", "status", "destination", "from", "to", "sort"];

const pad = (n) => String(n).padStart(2, "0");

function formatDate(d) {
  const x = new Date(d);
  if (isNaN(x)) return "-";
  return (
    pad(x.getDate()) +
    "." +
    pad(x.getMonth() + 1) +
    "." +
    x.getFullYear() +
    " " +
    pad(x.getHours()) +
    ":" +
    pad(x.getMinutes())
  );
}

const badge = (s) => `<span class="badge ${s}">${s}</span>`;

async function bookOffer(id) {
  const ok = confirm("Confirm booking?");
  if (!ok) return;

  try {
    const res = await fetch(`/api/offers/${id}/book`, {
      method: "POST"
    });

    const data = await res.json();

    if (!res.ok || !data.success) {
      alert(data.message || "Booking failed");
      return;
    }

    alert("Offer booked successfully.");
    loadOffers();
    loadStats();
    loadHotDeals();
    loadSalesBoard();
  } catch (e) {
    alert("Booking failed.");
  }
}

function row(offer) {
  const link = `${location.origin}/offer/${offer.id}`;
  const effectiveStatus = offer.effectiveStatus || offer.status || "draft";
  const isClosed = ["booked", "lost", "cancelled", "expired"].includes(effectiveStatus);

  return `
    <div class="card">
      <div class="row1">
        <div>
          ${badge(effectiveStatus)}
          <div class="dest">${offer.destination || "Untitled Offer"}</div>
          <div class="subline">
            ${offer.clientName || "No client"} · ${offer.flightRoute || "No route"} · ${offer.hotel || "No hotel"}
          </div>
        </div>
        <div class="price">${Number(offer.price || 0).toFixed(2)} ${offer.currency || "EUR"}</div>
      </div>

      <div class="meta">
        <div class="box"><div class="l">Offer ID</div><div class="v">${offer.id}</div></div>
        <div class="box"><div class="l">Client Phone</div><div class="v">${offer.clientPhone || "-"}</div></div>
        <div class="box"><div class="l">Created</div><div class="v">${formatDate(offer.createdAt)}</div></div>
        <div class="box"><div class="l">Valid Until</div><div class="v">${formatDate(offer.validUntil)}</div></div>
        <div class="box"><div class="l">Guests</div><div class="v">${offer.guests || "-"}</div></div>
        <div class="box"><div class="l">Base Price</div><div class="v">${Number(offer.basePrice || 0).toFixed(2)} ${offer.currency || "EUR"}</div></div>
        <div class="box"><div class="l">Markup</div><div class="v">${Number(offer.markupPercent || 0).toFixed(2)}%</div></div>
        <div class="box"><div class="l">Margin</div><div class="v">${(Number(offer.price || 0) - Number(offer.basePrice || 0)).toFixed(2)} ${offer.currency || "EUR"}</div></div>
        <div class="box"><div class="l">Deal Score</div><div class="v">${offer.dealScore ?? 0}</div></div>
        <div class="box"><div class="l">Urgency Score</div><div class="v">${offer.urgencyScore ?? 0}</div></div>
        <div class="box"><div class="l">Client Temp</div><div class="v">${offer.clientTemperature || "cold"}</div></div>
        <div class="box"><div class="l">Next Action</div><div class="v">${offer.nextAction || "Monitor"}</div></div>
      </div>

      <div class="actions">
        <select data-id="${offer.id}" class="status-select">
          ${["draft", "sent", "viewed", "booked", "lost", "cancelled"]
            .map(
              (s) =>
                `<option value="${s}" ${offer.status === s ? "selected" : ""}>${s}</option>`
            )
            .join("")}
        </select>
        <a class="btn" href="/offer/${offer.id}" target="_blank">Client Page</a>
        <a class="btn" href="/api/offers/${offer.id}/pdf" target="_blank">PDF</a>
        ${isClosed ? "" : `<button class="btn" data-book="${offer.id}">Book</button>`}
        <button class="btn copy-link" data-link="${link}">Copy Link</button>
      </div>
    </div>
  `;
}

function miniList(title, items) {
  return `
    <div class="kpi">
      <div class="label">${title}</div>
      <div style="margin-top:10px; display:grid; gap:8px;">
        ${
          items.length
            ? items
                .map(
                  (o) => `
          <div style="font-size:13px; line-height:1.35;">
            <b>${o.destination || "Untitled"}</b><br>
            <span style="opacity:.75">${o.clientName || "No client"}</span><br>
            <span style="opacity:.75">${Number(o.price || 0).toFixed(2)} ${o.currency || "EUR"}</span>
          </div>
        `
                )
                .join("")
            : `<div class="empty">No data</div>`
        }
      </div>
    </div>
  `;
}

function miniListWithAction(title, items) {
  return `
    <div class="kpi">
      <div class="label">${title}</div>
      <div style="margin-top:10px; display:grid; gap:8px;">
        ${
          items.length
            ? items
                .map(
                  (o) => `
          <div style="font-size:13px; line-height:1.35;">
            <b>${o.destination || "Untitled"}</b><br>
            <span style="opacity:.75">${o.clientName || "No client"}</span><br>
            <span style="opacity:.75">${Number(o.price || 0).toFixed(2)} ${o.currency || "EUR"}</span><br>
            <span style="opacity:.75">Action: ${o.nextAction || "Monitor"}</span>
          </div>
        `
                )
                .join("")
            : `<div class="empty">No data</div>`
        }
      </div>
    </div>
  `;
}

async function loadStats() {
  const res = await fetch("/api/offers/stats");
  const data = await res.json();

  adminStats.innerHTML = `
    <div class="kpi"><div class="label">Total Offers</div><div class="value">${data.totalOffers || 0}</div></div>
    <div class="kpi"><div class="label">Active Offers</div><div class="value">${data.activeOffers || 0}</div></div>
    <div class="kpi"><div class="label">Revenue Potential</div><div class="value">${Number(data.totalRevenuePotential || 0).toFixed(2)} EUR</div></div>
    <div class="kpi"><div class="label">Margin Potential</div><div class="value">${Number(data.totalMarginPotential || 0).toFixed(2)} EUR</div></div>
    <div class="kpi"><div class="label">Booked Revenue</div><div class="value">${Number(data.bookedRevenue || 0).toFixed(2)} EUR</div></div>
    <div class="kpi"><div class="label">Lost Revenue</div><div class="value">${Number(data.lostRevenue || 0).toFixed(2)} EUR</div></div>
  `;
}

async function loadHotDeals() {
  try {
    const res = await fetch("/api/offers/hot-deals");
    const data = await res.json();

    hotDealWidgets.innerHTML = `
      ${miniList("🔥 Hot Deals", data.hotDeals || [])}
      ${miniList("⏰ Expiring Soon", data.expiringSoon || [])}
      ${miniList("💰 High Margin", data.highMargin || [])}
      ${miniList("📞 Follow-up Required", data.followUpRequired || [])}
    `;
  } catch (e) {
    hotDealWidgets.innerHTML = "";
  }
}

async function loadSalesBoard() {
  try {
    const res = await fetch("/api/offers/sales-board");
    const data = await res.json();

    salesBoardWidgets.innerHTML = `
      ${miniListWithAction("🔥 Hot Clients", data.hotClients || [])}
      ${miniListWithAction("📞 Call Today", data.callToday || [])}
      ${miniListWithAction("💰 Close Deals", data.closeDeals || [])}
      ${miniListWithAction("❄ Cold Leads", data.coldLeads || [])}
    `;
  } catch (e) {
    salesBoardWidgets.innerHTML = "";
  }
}

async function loadOffers() {
  const params = new URLSearchParams();

  filterIds.forEach((id) => {
    const el = document.getElementById(id);
    if (!el) return;
    const value = el.value;
    if (value) params.set(id, value);
  });

  const res = await fetch(`/api/offers?${params.toString()}`);
  const data = await res.json();
  const offers = Array.isArray(data) ? data : data.offers || [];

  if (!offers.length) {
    adminOffers.innerHTML = '<div class="empty">No matching offers.</div>';
    return;
  }

  adminOffers.innerHTML = offers.map(row).join("");

  document.querySelectorAll(".status-select").forEach((sel) =>
    sel.addEventListener("change", async () => {
      await fetch(`/api/offers/${sel.dataset.id}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: sel.value })
      });

      loadOffers();
      loadStats();
      loadHotDeals();
      loadSalesBoard();
    })
  );

  document.querySelectorAll(".copy-link").forEach((btn) =>
    btn.addEventListener("click", async () => {
      await navigator.clipboard.writeText(btn.dataset.link);
      btn.textContent = "Copied";
      setTimeout(() => {
        btn.textContent = "Copy Link";
      }, 1200);
    })
  );

  document.querySelectorAll("[data-book]").forEach((btn) =>
    btn.addEventListener("click", async () => {
      await bookOffer(btn.dataset.book);
    })
  );
}

filterIds.forEach((id) => {
  const el = document.getElementById(id);
  if (!el) return;
  el.addEventListener("input", loadOffers);
  el.addEventListener("change", loadOffers);
});

loadStats();
loadOffers();
loadHotDeals();
loadSalesBoard();